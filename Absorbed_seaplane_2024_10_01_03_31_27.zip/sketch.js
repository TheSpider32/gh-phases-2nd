value = 30;

function setup() {
    createCanvas(400, 400);
    stroke(0)
    strokeWeight(value);}

function mousePressed() {
  if (value == 30) {
    strokeWeight(5);
  }
}

function draw() {
  background(220);
  for (var i = 20; i < 400; i += 60)
  line (40, 0, 70, height);
  if (keyIsPressed) {
  line(240, 20, 20, 100);

 }
  
}