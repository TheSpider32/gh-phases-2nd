function setup() {
  
    createCanvas(400, 400);

    // Prints "hello, world" to the console.
  print('Whooo, goes there?');

}

function draw() {
  
    background(220);

    owl(160, 90); // calling the 'owl' function, passing x and y position coordinates

    owl(160, 90); // calling the 'owl' function a second time with new x and y position coordinates
}

function owl(x, y) {

    push(); // create a new drawing state

    translate(x, y);

    stroke(0);

    strokeWeight(80);

    line (0, -35, 0, -65); // Body

    noStroke();

    fill(255);

    ellipse(-17.5, -65, 35, 35); // Left eye dome
  
    ellipse(17.5, -65, 35, 35); // Right eye dome

    arc(0, -65, 70, 70, 0, PI); // Chin

    fill(0);

    ellipse(-14, -65, 8, 8); // Left eye

    ellipse(14, -65, 8, 8); // Right eye

    quad(0, -58, 4, -51, 0, -44, -4, -51); // Beak

    pop(); // return the drawing state to it's orginal state, before the push() function

}