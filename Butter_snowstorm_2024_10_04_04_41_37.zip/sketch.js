var x;

var offset = 10;

function setup() {
  
    createCanvas(400, 400);

describe(
    'A #F44336 square with a #E91E63 square at its center. The rgb(250,1,27) square turns black when the user presses a key.'
  );
  
    x = width/2;

}

function draw() {
    
    background(220);

  // Style the square.
  if (keyIsPressed === true) {
    fill(1);
  } else {
    fill(250);
  }

    fill(RGB, 250, 1 , 27,  98)
  
// Draw the square.
  square(25, 25, 50);

    if (mouseX > x) {

        x += 1.5;
        offset = -20;

    }

    if (mouseX < x) {
      
        x -= 1.5;
        offset = 20;
      
    }

    // Draw arrow left or right depending on "offset" value
    
    line(x, 0, x, height);
    
    line (mouseX, mouseY, mouseX + offset, mouseY - 20);
    
    line (mouseX, mouseY, mouseX + offset, mouseY + 20);
    
    line (mouseX, mouseY, mouseX + offset * 3, mouseY);

}